const http = require('http')
const url = require('url')
const dgram = require('dgram')
const { StringDecoder } = require('string_decoder')

const PORT = process.env.PORT || 3000

// HTTP / TCP Server
const server = http.createServer((req, res) => {
	var path = require('path');
	var fs = require('fs');
	
     // The requested URL, like http://localhost:3000/file.html => /file.html
    var uri = url.parse(req.url).pathname;
    // get the /file.html from above and then find it from the current folder
    var filename = path.join(process.cwd(), uri);

    // Setting up MIME-Type (YOU MAY NEED TO ADD MORE HERE) <--------
    var contentTypesByExtension = {
        '.html': 'text/html',
        '.css':  'text/css',
        '.js':   'text/javascript',
        '.json': 'text/json',
        '.svg':  'image/svg+xml'
    };

    // Check if the requested file exists
    fs.exists(filename, function (exists) {
        // If it doesn't
        if (!exists) {
            // Output a red error pointing to failed request
            console.log('Fail: ' + filename);
            // Redirect the browser to the 404 page
            filename = path.join(process.cwd(), '/404.html');
        // If the requested URL is a folder, like http://localhost:8000/catpics
        } else if (fs.statSync(filename).isDirectory()) {
            // redirect the user to the index.html in the requested folder
            filename += '/index.html';
        }

        // Assuming the file exists, read it
        fs.readFile(filename, 'binary', function (err, file) {
            // If there was an error trying to read the file
            if (err) {
                // Put the error in the browser
                res.writeHead(500, {'Content-Type': 'text/plain'});
                res.write(err + '\n');
                res.end();
                return;
            }

            // Otherwise, declare a headers object and a var for the MIME-Type
            var headers = {};
            var contentType = contentTypesByExtension[path.extname(filename)];
			
            // If the requested file has a matching MIME-Type
            if (contentType) {
                // Set it in the headers
                headers['Content-Type'] = contentType;
            }
			
            // Output the read file to the browser for it to load
            res.writeHead(200, headers);
            res.write(file, 'binary');
            res.end();
        });
    });	
})


// UDP Server
const express = require('express');
const app = express();
const { Server } = require("socket.io");
const io = new Server(server);

// Connessioni
connections = [];

const socket = dgram.createSocket(
  {
    type: 'udp4',
    reuseAddr: true // <- NOTE: we are asking OS to let us reuse port
  },
  (buffer, sender) => {
	io.sockets.on('connection', function(socket) {
		// Connect Socket
		connections.push(socket);
						
		console.log('Socket:' + connections.length + ' Socket-id:' + socket.id);
						
		// Disconnect
		socket.on('disconnect', function(data) {
			connections.splice(connections.indexOf(socket), 1);
			console.log(socket.id + ' Disconnected: %s sockets connected', connections.length);
		});
		
		// Messaggio UDP del flusso video
		socket.on('VideoStream', (message) => {
			io.emit('VideoStream', message);
		});
		
		// Messaggio UDP della chat per ottenere l'IP dal server
		socket.on('chat message', (message) => {
			if (message=='Host-IP')
			{
				io.emit('chat message', 'ServerURL_' + sender.address + ':' + sender.port);
			}
			else
			{
				io.emit('chat message', message);
			}
		});	
	});
  }
)

// POI: bind two servers to same port
server.listen(PORT)
socket.bind(PORT)


// Message to display when server is started
console.log('\nStatic file server running at http://localhost:' + PORT + '/\nCTRL + C to shutdown');

// Apro la porta di comunicazione
socket.on('listening', () => {
  socket.setBroadcast(true)

  // 255.255.255.255 - boradcast for local network - RFC922
  socket.send('hi', PORT, '255.255.255.255', (err) => {
    console.log(err ? err : 'Sended')
  })

  // risposta da se stesso (server)
  socket.on('message', (buffer, sender) => {
    const message = buffer.toString()
    console.log(`Received message: ${message} from ${sender.address} port:${sender.port}`)
	
    socket.close()
  })

})



