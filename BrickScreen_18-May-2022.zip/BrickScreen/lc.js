

// Cookies per memorizzare l'ID del client
let cookies = navigator.cookieEnabled;

function setCookie(cname, cvalue, exdays) 
{
	const d = new Date();
	d.setTime(d.getTime() + (exdays*24*60*60*1000));
	let expires = "expires=" + d.toUTCString();
	document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) 
{
	let name = cname + "=";
	let decodedCookie = decodeURIComponent(document.cookie);
	let ca = decodedCookie.split(';');
	for(let i = 0; i < ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}

function eraseCookie(name, label) 
{   
	document.cookie = name+'=; Max-Age=-99999999;'; 
	label.value = '';
}

function checkCookie(label) 
{
	let user = getCookie("username");

	if (user != "") {
		label.value = user;
	} 
	else 
	{ 
		var d = new Date();
										
		// ID univoco con numero di digits fisso										
		var id = d.getFullYear().toString().substr(-2) + 
			("0"+(d.getMonth()+1)).slice(-2) + 
			("0" + d.getDate()).slice(-2) + 
			("0" + d.getHours()).slice(-2) + 
			("0" + d.getMinutes()).slice(-2) + 
			("0" + d.getSeconds()).slice(-2) + 
			(1000 + d.getMilliseconds()).toString().substr(1);
												
		label.value = id;
		setCookie("username", id, 30);
	}
}

function openFullscreen() 
{
	var elem = document.documentElement;
	
	if (elem.requestFullscreen) {
		elem.requestFullscreen();
	} else if (elem.webkitRequestFullscreen) { /* Safari */
		elem.webkitRequestFullscreen();
	} else if (elem.msRequestFullscreen) { /* IE11 */
		elem.msRequestFullscreen();
	}
}

function closeFullscreen() 
{
	if (document.exitFullscreen) {
		document.exitFullscreen();
	} else if (document.webkitExitFullscreen) { /* Safari */
		document.webkitExitFullscreen();
	} else if (document.msExitFullscreen) { /* IE11 */
		document.msExitFullscreen();
	}
}
			
function Move(Controllo, Direzione, Step)
{
	Controllo.style.position="absolute";
	
	if (Direzione=='Up')
	{
		var y = Controllo.offsetTop;		
		y = y - Step
		Controllo.style.top = y + "px"; 
	}
	else if (Direzione=='Down')
	{
		var y = Controllo.offsetTop;		
		y = y + Step
		Controllo.style.top = y + "px"; 
	}
	else if (Direzione=='Left')
	{
		var x = Controllo.offsetLeft;		
		x = x - Step
		Controllo.style.left = x + "px"; 
	}
	else if (Direzione=='Right')
	{
		var x = Controllo.offsetLeft;		
		x = x + Step
		Controllo.style.left = x + "px"; 
	}
}

function ResizeVideo(canvas, zoom, step, VideoSourceW, VideoSourceH, windowInnerWidth, windowInnerHeight) 
{
	var canvasRatio = VideoSourceH / VideoSourceW;
	var w;
	var h;
					
	if (zoom == 'decrease')
	{
		// decrease
		w = canvas.width - step;
		h = w * canvasRatio;
		
		// Dimensioni finali
		canvas.width = w;
		canvas.height = h;
	}
	else if (zoom == 'increase')
	{
		// increase
		w = canvas.width + step;
		h = w * canvasRatio;
		
		// Dimensioni finali
		canvas.width = w;
		canvas.height = h;
	}
	else if (zoom == 'fit')
	{
		var windowRatio = windowInnerHeight / windowInnerWidth;
		
		if (windowRatio < canvasRatio) {
			h = window.innerHeight;
			w = h / canvasRatio;
		} else {
			w = window.innerWidth;
			h = w * canvasRatio;
		}

		// Dimensioni finali
		canvas.width = w;
		canvas.height = h;
			
		// Posizione X
		canvas.style.left = (parseInt(windowInnerWidth/2) - parseInt(w/2)) + "px";
		// Posizione Y		
		canvas.style.top = (parseInt(windowInnerHeight/2) - parseInt(h/2)) + "px";
	}
}

function HideAndShow( valore, Q, V, C ) 
{
	if (valore=='Show_Command')
	{
		// Nascondo il QR code
		Q.style.display = "none";  
		
		// Mostro il Canvas del video
		V.style.display = "block";  
		
		// Mostro i Comandi
		C.style.display = "block";  
	}
	else if (valore=='Hide_Command')
	{					
		// Nascondo i Comandi
		C.style.display = "none";  
	}
	else if (valore=='Show_QRcode')
	{
		// Mostro il QR code
		Q.style.display = "block";  
	
		// Nascondo i Comandi
		C.style.display = "none";  
		
		// Nascondo il Canvas del video
		V.style.display = "none";  
		
		// Colore verde
		document.body.style.background = "#7FFF00";
	}
	else if (valore=='Show_Video')
	{				
		// Mostro il Canvas del video
		V.style.display = "block";  
		
		// Nascondo il QR code
		Q.style.display = "none";  
	
		// Nascondo i Comandi
		C.style.display = "none"; 
		
		// Colore nero
		document.body.style.background = "#000000";
	}
} 		

function drawCircle_Slave(ctx, x, y, radius, fill, stroke, strokeWidth) 
{
	ctx.beginPath()
	ctx.arc(x, y, radius, 0, 2 * Math.PI, false)
	if (fill) {
		ctx.fillStyle = fill
		ctx.fill()
	}
	if (stroke) {
		ctx.lineWidth = strokeWidth
		ctx.strokeStyle = stroke
		ctx.stroke()
	}
}